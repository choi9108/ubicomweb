package com.ubicom.Ubicom;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.csrf((csrf) -> csrf.disable());
        http.authorizeHttpRequests((authorize) ->
                authorize.requestMatchers("/**").permitAll()
        );

        // 폼 로그인 규격 및 성공/실패 처리 설정
        http.formLogin((form) -> form
                .loginPage("/login.html")         // 로그인 처리 및 페이지 경로 지정
                .loginProcessingUrl("/login")     // HTML form의 action 주소와 일치시킴
                .defaultSuccessUrl("/", true)     // 로그인 성공 시 메인 레이아웃 페이지로 이동
                .failureUrl("/login.html?error=true") // 실패 시 에러 파라미터를 들고 로그인창으로 이동
        );

        // 로그아웃 설정 추가
        http.logout((logout) -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/")
                .deleteCookies("JSESSIONID")
        );
        return http.build();
    }
}