package com.ubicom.Ubicom;

import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class MemberController {

    private final MemberRepository memberRepository;
    private final UsersRepository usersRepository;
    private final PasswordEncoder passwordEncoder;

    @GetMapping("/register")
    public String register() {
        return "forward:/register.html";
    }

    @PostMapping("/member")
    public String addMember(
            String name,
            Integer userid,
            String major,
            String password,
            HttpServletResponse response
    ) throws Exception {

        var result = usersRepository.findByUserId(userid);
        var result2 = memberRepository.findByUserId(userid);
        // 1. 학번 자릿수 검증 (8자리)
        if (userid == null || (int)(Math.log10(userid) + 1) != 8) {
            showAlert(response, "학번 8자리를 정확히 입력해주세요.");
            return null; // 스크립트를 실행하므로 뒤의 뷰 리턴은 무시됨
        }

        // 2. 존재하지 않는 학번 검증
        if (result.isEmpty()) {
            showAlert(response, "존재하지 않는 학번입니다.");
            return null;
        }

        // 3. 이미 등록된 학번 검증
        if (result2.isPresent()) {
            showAlert(response, "이미 등록된 학번입니다.");
            return null;
        }



        // 회원 가입 진행
        Member member = new Member();
        member.setName(name);
        member.setUserId(userid);
        member.setMajor(major);

        var hash = passwordEncoder.encode(password);
        member.setPassword(hash);

        memberRepository.save(member);

        return "redirect:/list";
    }

    // 알림창을 띄우고 /register로 이동시키는 메소드
    private void showAlert(HttpServletResponse response, String message) throws IOException {
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<script>");
        out.println("alert('" + message + "');");
        out.println("location.href='/register';"); // 다시 회원가입 페이지로 이동
        out.println("</script>");
        out.flush();
    }

    //로그인 로직
    @GetMapping("/login")
    public String login()
    {
        return "forward:/login.html";
    }

    @Service
    @RequiredArgsConstructor // 1. memberRepository 주입을 위한 롬복 어노테이션
    public class MyUserDetailsService implements UserDetailsService {

        private final MemberRepository memberRepository; // 2. 리포지토리 의존성 주입

        @Override
        public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

            // 3. 시큐리티가 전달해 준 문자열(username)을 학번(Integer)으로 변환
            Integer userId;
            try {
                userId = Integer.parseInt(username);
            } catch (NumberFormatException e) {
                throw new UsernameNotFoundException("학번 형식이 올바르지 않습니다.");
            }

            // 4. DB에서 해당 학번 조회
            var result = memberRepository.findByUserId(userId);
            if (result.isEmpty()) {
                throw new UsernameNotFoundException("가입이 되지 않은 학번입니다.");
            }

            var user = result.get();

            // 5. 시큐리티 규격에 맞는 User 객체 생성 및 반환
            // 인자 순서: (문자열_아이디, 암호화된_비밀번호, 권한_리스트)
            return new User(
                    String.valueOf(user.getuserId()),
                    user.getpassword(),
                    List.of(new SimpleGrantedAuthority("일반회원")) // 기본 유저 권한 부여
            );
        }
    }

}